/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

#include "stm32g4xx_ll_dma.h"
#include "stm32g4xx_ll_tim.h"
#include "stm32g4xx_ll_system.h"
#include "stm32g4xx_ll_gpio.h"
#include "stm32g4xx_ll_exti.h"
#include "stm32g4xx_ll_bus.h"
#include "stm32g4xx_ll_cortex.h"
#include "stm32g4xx_ll_rcc.h"
#include "stm32g4xx_ll_utils.h"
#include "stm32g4xx_ll_pwr.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "global_include.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define R_EN_Pin LL_GPIO_PIN_13
#define R_EN_GPIO_Port GPIOC
#define LCD_RES_Pin LL_GPIO_PIN_14
#define LCD_RES_GPIO_Port GPIOC
#define LCD_DC_Pin LL_GPIO_PIN_15
#define LCD_DC_GPIO_Port GPIOC
#define V_A_Pin LL_GPIO_PIN_0
#define V_A_GPIO_Port GPIOC
#define V_B_Pin LL_GPIO_PIN_1
#define V_B_GPIO_Port GPIOC
#define V_C_Pin LL_GPIO_PIN_2
#define V_C_GPIO_Port GPIOC
#define SENSE_C_Pin LL_GPIO_PIN_0
#define SENSE_C_GPIO_Port GPIOA
#define SENSE_B_Pin LL_GPIO_PIN_1
#define SENSE_B_GPIO_Port GPIOA
#define SENSE_A_Pin LL_GPIO_PIN_2
#define SENSE_A_GPIO_Port GPIOA
#define SENSE_BUS_Pin LL_GPIO_PIN_3
#define SENSE_BUS_GPIO_Port GPIOA
#define RGB_Pin LL_GPIO_PIN_5
#define RGB_GPIO_Port GPIOA
#define HALL_A_Pin LL_GPIO_PIN_6
#define HALL_A_GPIO_Port GPIOA
#define HALL_B_Pin LL_GPIO_PIN_7
#define HALL_B_GPIO_Port GPIOA
#define POT_Pin LL_GPIO_PIN_4
#define POT_GPIO_Port GPIOC
#define V_BUS_Pin LL_GPIO_PIN_5
#define V_BUS_GPIO_Port GPIOC
#define HALL_C_Pin LL_GPIO_PIN_0
#define HALL_C_GPIO_Port GPIOB
#define NTC1_Pin LL_GPIO_PIN_1
#define NTC1_GPIO_Port GPIOB
#define NTC3_Pin LL_GPIO_PIN_12
#define NTC3_GPIO_Port GPIOB
#define SPI3_CS_Pin LL_GPIO_PIN_15
#define SPI3_CS_GPIO_Port GPIOA
#define SPI1_CSN_Pin LL_GPIO_PIN_2
#define SPI1_CSN_GPIO_Port GPIOD
#define LCD_CS_Pin LL_GPIO_PIN_6
#define LCD_CS_GPIO_Port GPIOB
#define LCD_BLK_Pin LL_GPIO_PIN_7
#define LCD_BLK_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
